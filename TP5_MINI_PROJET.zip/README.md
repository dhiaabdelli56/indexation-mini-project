# TP5 SRI Project
Run: python interface/app.py
