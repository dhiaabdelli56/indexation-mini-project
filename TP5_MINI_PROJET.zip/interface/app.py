import tkinter as tk
import os

from indexation.extracteur import lire_documents
from indexation.preprocesseur import nettoyer
from indexation.indexeur import idf, tf_idf
from modeles.vectoriel import cosinus

DOSSIER = "collections"

docs_bruts = lire_documents(DOSSIER)
docs = {k: nettoyer(v) for k,v in docs_bruts.items()}
idf_dict = idf(docs)
vecteurs = {k: tf_idf(v,idf_dict) for k,v in docs.items()}

def rechercher():
    requete = entry.get()
    mots = nettoyer(requete)
    req_vec = tf_idf(mots,idf_dict)

    scores = []
    for doc,vec in vecteurs.items():
        score = cosinus(req_vec,vec)
        scores.append((doc,score))

    scores.sort(key=lambda x:x[1], reverse=True)

    resultats.delete(0,tk.END)
    for doc,score in scores:
        resultats.insert(tk.END, f"{doc} | score={round(score,3)}")

def ouvrir_doc(event):
    selection = resultats.get(resultats.curselection())
    nom = selection.split("|")[0].strip()
    chemin = os.path.join(DOSSIER,nom)
    os.startfile(chemin)

root = tk.Tk()
root.title("SRI")
root.geometry("700x500")

entry = tk.Entry(root,width=40)
entry.pack(pady=10)

btn = tk.Button(root,text="Rechercher",command=rechercher)
btn.pack()

resultats = tk.Listbox(root)
resultats.pack(fill="both",expand=True)
resultats.bind("<Double-1>",ouvrir_doc)

root.mainloop()
