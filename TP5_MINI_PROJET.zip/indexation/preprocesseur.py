import re

stopwords = ["le","la","les","de","des","un","une","et"]

def nettoyer(texte):
    texte = texte.lower()
    texte = re.sub(r"[^a-zA-Z ]","",texte)
    mots = texte.split()
    return [m for m in mots if m not in stopwords]
