import math
from collections import Counter

def tf(mots):
    return Counter(mots)

def idf(docs):
    N = len(docs)
    idf_dict = {}
    all_words = set(word for doc in docs.values() for word in doc)
    for word in all_words:
        df = sum(1 for doc in docs.values() if word in doc)
        idf_dict[word] = math.log(N/(df+1))
    return idf_dict

def tf_idf(doc,idf_dict):
    tf_dict = tf(doc)
    return {w: tf_dict[w]*idf_dict.get(w,0) for w in tf_dict}
