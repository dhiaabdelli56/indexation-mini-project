import os

def lire_documents(dossier):
    docs = {}
    for fichier in os.listdir(dossier):
        chemin = os.path.join(dossier, fichier)
        if fichier.endswith(".txt"):
            with open(chemin, "r", encoding="utf-8") as f:
                docs[fichier] = f.read()
    return docs
