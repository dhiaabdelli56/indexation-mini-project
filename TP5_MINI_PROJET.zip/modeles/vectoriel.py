import math

def cosinus(v1,v2):
    dot = sum(v1.get(k,0)*v2.get(k,0) for k in v1)
    n1 = math.sqrt(sum(v**2 for v in v1.values()))
    n2 = math.sqrt(sum(v**2 for v in v2.values()))
    if n1==0 or n2==0:
        return 0
    return dot/(n1*n2)
